# Laboratory Practice 1

## List of Assignments

### Group A
1. [Assembler](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Assembler)
   - [Pass 1](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Assembler/Pass-1)
   - [Pass 2](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Assembler/Pass-2)
   
3. [Macro Assembler](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Macro-Assembler)
   - [Pass 1](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Macro-Assembler/Pass-1)
   - [Pass 2](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Macro-Assembler/Pass-2)

### Group B

1. [Synchronization](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Synchronization)
2. [Scheduling](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Scheduling)
3. [Memory Management](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Memory-Mgmt)

### Group C (Elective)

1. [Socket Programming](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Socket-Programming)
2. [Ring and Bully Election](https://github.com/shxntanu/TE-Lab-Assignments/tree/934137cf556770999166b3a163c97163189f6237/Election)

<div align="center">
  <img src="https://profile-counter.glitch.me/shxntanu/count.svg?"  />
</div>
